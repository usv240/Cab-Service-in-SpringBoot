package com.cab.cabservice.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cab.cabservice.custom.mapper.addCustomerDriverMapper;
import com.cab.cabservice.dto.CabDriverDto;
import com.cab.cabservice.dto.UserDto;

// TODO: Auto-generated Javadoc
/**
 * The Class CustomerManagementServiceImpl.
 */
@Service
public class CustomerManagementServiceImpl {

	/** The mapper. */
	@Autowired
	addCustomerDriverMapper mapper;

	/**
	 * Adds the user.
	 *
	 * @param customerDto the customer dto
	 * @return the int
	 */
	public int addUser(UserDto customerDto) {
		mapper.addCustomer(customerDto.getUserName(), customerDto.getPhone(), customerDto.getLastName(),
				customerDto.getFirstName(), customerDto.getEmail());
		return 0;
	}

	/**
	 * Adds the cab driver.
	 *
	 * @param cabDriverDto the cab driver dto
	 * @return the int
	 */
	public int addCabDriver(CabDriverDto cabDriverDto) {

		mapper.addCab(cabDriverDto.getUserName(), cabDriverDto.getPhone(), cabDriverDto.getLastName(),
				cabDriverDto.getFirstName(), cabDriverDto.getEmail(), cabDriverDto.getVehicle_num());

		return 0;
	}

}
