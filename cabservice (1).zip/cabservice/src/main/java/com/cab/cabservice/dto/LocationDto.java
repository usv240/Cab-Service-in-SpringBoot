package com.cab.cabservice.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// TODO: Auto-generated Javadoc
/**
 * Hash code.
 *
 * @return the int
 */
@Data

/**
 * Instantiates a new location dto.
 */
@NoArgsConstructor

/**
 * Gets the location.
 *
 * @return the location
 */
@Getter

/**
 * Sets the location.
 *
 * @param location the new location
 */
@Setter

/**
 * To string.
 *
 * @return the java.lang. string
 */
@ToString
public class LocationDto {

	/** The username. */
	public String username;

	/** The location. */
	public String location;

}
