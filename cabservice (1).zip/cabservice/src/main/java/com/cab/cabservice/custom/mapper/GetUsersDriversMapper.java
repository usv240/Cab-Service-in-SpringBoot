package com.cab.cabservice.custom.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.cab.cabservice.dto.LocationDto;

// TODO: Auto-generated Javadoc
/**
 * The Interface GetUsersDriversMapper.
 */
@Mapper
public interface GetUsersDriversMapper {

	/** The get users. */
	String getUsers = "SELECT username, present_location\r\n" + "	FROM public.waitlist_user; ";

	/** The get driver. */
	String getDriver = "SELECT username, present_location\r\n" + "	FROM public.waitlist_cab;";

	/** The delete from user wait list. */
	String deleteFromUserWaitList = "DELETE FROM public.waitlist_user\r\n" + "	WHERE username=#{username};";

	/** The delete from driver wait list. */
	String deleteFromDriverWaitList = "DELETE FROM public.waitlist_cab\r\n" + "	WHERE username=#{cabname};";

	/** The add to on going rides. */
	String addToOnGoingRides = "INSERT INTO public.ongoingride\r\n"
			+ "(username_driver, username_users, start_location, end_location, status)\r\n"
			+ "VALUES(#{cabname}, #{username}, '', '', '');";

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	@Select(getUsers)
	@Results(value = {

			@Result(property = "username", column = "username"),
			@Result(property = "location", column = "present_location"),

	})
	public List<LocationDto> getUser();

	/**
	 * Gets the cab.
	 *
	 * @return the cab
	 */
	@Select(getDriver)
	@Results(value = {

			@Result(property = "username", column = "username"),
			@Result(property = "location", column = "present_location"),

	})
	public List<LocationDto> getCab();

	/**
	 * Delete from user wait list.
	 *
	 * @param username the username
	 */
	@Select(deleteFromUserWaitList)
	public void deleteFromUserWaitList(String username);

	/**
	 * Delete from driver wait list.
	 *
	 * @param cabname the cabname
	 */
	@Select(deleteFromDriverWaitList)
	public void deleteFromDriverWaitList(String cabname);

	/**
	 * Adds the to on going rides.
	 *
	 * @param username the username
	 * @param cabname  the cabname
	 */
	@Select(addToOnGoingRides)
	public void addToOnGoingRides(String username, String cabname);
}
