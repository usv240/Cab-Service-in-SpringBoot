package com.cab.cabservice.custom.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.cab.cabservice.dto.UserDto;

// TODO: Auto-generated Javadoc
/**
 * The Interface addCustomerDriverMapper.
 */
@Mapper
public interface addCustomerDriverMapper {

	/** The add customer. */
	String addCustomer = "INSERT INTO users(\r\n" + "	name, username, phone, email_id)\r\n"
			+ "	VALUES (concat(#{firstName},' ',#{lastName}),#{userName}, #{phone}, #{email});";

	/** The add cab. */
	String addCab = " INSERT INTO public.cardriver(\r\n" + "	name, username, phone, email_id, vehicle_num)\r\n"
			+ "	VALUES (concat(#{firstName},' ',#{lastName}),#{userName}, #{phone}, #{email},#{vehicle_num});";

	/**
	 * Adds the customer.
	 *
	 * @param userName  the user name
	 * @param phone     the phone
	 * @param lastName  the last name
	 * @param firstName the first name
	 * @param email     the email
	 */
	@Select(addCustomer)
	public void addCustomer(String userName, String phone, String lastName, String firstName, String email);

	/**
	 * Adds the cab.
	 *
	 * @param userName    the user name
	 * @param phone       the phone
	 * @param lastName    the last name
	 * @param firstName   the first name
	 * @param email       the email
	 * @param vehicle_num the vehicle num
	 */
	@Select(addCab)
	public void addCab(String userName, String phone, String lastName, String firstName, String email,
			String vehicle_num);

}
