package com.cab.cabservice.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// TODO: Auto-generated Javadoc
/**
 * Hash code.
 *
 * @return the int
 */
@Data

/**
 * Instantiates a new on going ride.
 */
@NoArgsConstructor

/**
 * Gets the status.
 *
 * @return the status
 */
@Getter

/**
 * Sets the status.
 *
 * @param status the new status
 */
@Setter

/**
 * To string.
 *
 * @return the java.lang. string
 */
@ToString
public class OnGoingRide {

	/** The user name driver. */
	public String userName_Driver;

	/** The user name user. */
	public String userName_User;

	/** The start location. */
	public String startLocation;

	/** The end location. */
	public String endLocation;

	/** The status. */
	public String status;

}
