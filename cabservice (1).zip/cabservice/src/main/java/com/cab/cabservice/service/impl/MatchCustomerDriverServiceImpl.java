package com.cab.cabservice.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cab.cabservice.custom.mapper.GetUsersDriversMapper;
import com.cab.cabservice.dto.LocationDto;

// TODO: Auto-generated Javadoc
/**
 * The Class MatchCustomerDriverServiceImpl.
 */
@Service
public class MatchCustomerDriverServiceImpl {

	/** The mapper. */
	@Autowired
	GetUsersDriversMapper mapper;

	/**
	 * Match drivers users.
	 */
	public void matchDriversUsers() {

		HashMap<String, String> Usermap = new HashMap<>();
		HashMap<String, String> Drivermap = new HashMap<>();

		for (;;) {
			List<LocationDto> userloc = mapper.getUser();
			List<LocationDto> driverloc = mapper.getCab();

			for (LocationDto temp : userloc) {
				Usermap.put(temp.username, temp.location);

			}

			for (LocationDto temp : driverloc) {
				Drivermap.put(temp.username, temp.location);

			}

			for (Map.Entry<String, String> Userentry : Usermap.entrySet()) {

				String username = Userentry.getKey();
				String location = Userentry.getValue();

				int x1 = Integer.parseInt(location.substring(0, location.indexOf(',')));
				int y1 = Integer.parseInt(location.substring(location.lastIndexOf(",") + 1));

				for (Map.Entry<String, String> Cabentry : Drivermap.entrySet()) {
					String Cabname = Cabentry.getKey();
					String Cablocation = Cabentry.getValue();

					int x2 = Integer.parseInt(Cablocation.substring(0, Cablocation.indexOf(',')));
					int y2 = Integer.parseInt(Cablocation.substring(Cablocation.lastIndexOf(",") + 1));

					double val = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) * 1.0);
					double distance = Math.round(val * 100000.0) / 100000.0;

					if (distance <= 5) {
						System.out.println("Matched Users are " + username + " and " + Cabname);
						Usermap.remove(username);
						Drivermap.remove(Cabname);
						mapper.deleteFromUserWaitList(username);
						mapper.deleteFromDriverWaitList(Cabname);
						mapper.addToOnGoingRides(username, Cabname);
					} else {
						continue;
					}

				}

			}

		}

	}

}
