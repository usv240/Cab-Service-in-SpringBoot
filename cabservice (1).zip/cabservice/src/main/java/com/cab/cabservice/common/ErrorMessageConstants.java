package com.cab.cabservice.common;

public class ErrorMessageConstants {

}
