package com.cab.cabservice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cab.cabservice.custom.mapper.addCustomerDriverMapper;
import com.cab.cabservice.custom.mapper.customerDriverWaitingListMapper;
import com.cab.cabservice.dto.WaitList_CabDto;
import com.cab.cabservice.dto.WaitList_UserDto;

// TODO: Auto-generated Javadoc
/**
 * The Class CustomerDriverWaitListServiceImpl.
 */
@Service
public class CustomerDriverWaitListServiceImpl {

	/** The mapper. */
	@Autowired
	customerDriverWaitingListMapper mapper;

	/**
	 * Adds the user wait list.
	 *
	 * @param waitListUserDto the wait list user dto
	 * @return the int
	 */
	public int addUserWaitList(WaitList_UserDto waitListUserDto) {
		mapper.addUserWaitingList(waitListUserDto.getPresentLocation(), waitListUserDto.getUserName());
		return 0;
	}

	/**
	 * Adds the cab driver wait list.
	 *
	 * @param waitListCabDto the wait list cab dto
	 * @return the int
	 */
	public int addCabDriverWaitList(WaitList_CabDto waitListCabDto) {
		mapper.addCabWaitingList(waitListCabDto.getPresentLocation(), waitListCabDto.getUserName());
		return 0;
	}

}
