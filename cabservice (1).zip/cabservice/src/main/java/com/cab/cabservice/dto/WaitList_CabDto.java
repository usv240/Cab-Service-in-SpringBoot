package com.cab.cabservice.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// TODO: Auto-generated Javadoc
/**
 * Hash code.
 *
 * @return the int
 */
@Data

/**
 * Instantiates a new wait list cab dto.
 */
@NoArgsConstructor

/**
 * Gets the present location.
 *
 * @return the present location
 */
@Getter

/**
 * Sets the present location.
 *
 * @param presentLocation the new present location
 */
@Setter

/**
 * To string.
 *
 * @return the java.lang. string
 */
@ToString
public class WaitList_CabDto {

	/** The user name. */
	public String userName;

	/** The present location. */
	public String presentLocation;

}
