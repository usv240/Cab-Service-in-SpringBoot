package com.cab.cabservice.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// TODO: Auto-generated Javadoc
/**
 * Hash code.
 *
 * @return the int
 */
@Data

/**
 * Instantiates a new user dto.
 */
@NoArgsConstructor

/**
 * Gets the email.
 *
 * @return the email
 */
@Getter

/**
 * Sets the email.
 *
 * @param email the new email
 */
@Setter

/**
 * To string.
 *
 * @return the java.lang. string
 */
@ToString
public class UserDto {

	/** The user name. */
	public String userName;

	/** The first name. */
	public String firstName;

	/** The last name. */
	public String lastName;

	/** The phone. */
	public String phone;

	/** The email. */
	public String email;

}
