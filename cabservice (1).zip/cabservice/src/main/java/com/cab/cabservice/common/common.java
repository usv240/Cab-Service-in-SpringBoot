package com.cab.cabservice.common;

public class common {
	
	public static final String ADD_USER="/addUser";
	
	
	public static final String ADD_CAB="/addDriver";
	
	
	
	
public static final String ADD_USER_TO_WAIT_LIST="/addUser/WaitList";
	
	
	public static final String ADD_CAB_TO_WAIT_LIST="/addDriver/WaitList";
	
	
	
	
	public static final String MATCH_USERS_WITH_DRIVERS="/match/UsersDrivers";
	
	
	public static final String FIND_RIDE="findRide";
	
	public static final String CHOOSE_RIDE="chooseRide";


	public static final String SUCCESS = "Success";
	
	
	
	  public static final String ADD_CUSTOMER="thesage/backend/addCustomer";
	  
	  public static final String UPDATE_CUSTOMER="thesage/backend/updateCustomer";
	 

}
