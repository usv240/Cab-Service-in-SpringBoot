/*
 * 
 */
package com.cab.cabservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.cors.CorsConfiguration;

import com.cab.cabservice.common.CustomResponse;
import com.cab.cabservice.common.Message;
import com.cab.cabservice.common.MessageConstants;
import com.cab.cabservice.common.common;
import com.cab.cabservice.dto.CabDriverDto;
import com.cab.cabservice.dto.UserDto;
import com.cab.cabservice.service.impl.CustomerManagementServiceImpl;

// TODO: Auto-generated Javadoc
/**
 * The Class CustomerDriverManagementController.
 */
@RestController
@Validated

@RequestMapping("/cabservice-api")
@CrossOrigin(origins = { "http://localhost:9000" }, methods = { RequestMethod.POST, RequestMethod.GET,
		RequestMethod.PUT,
		RequestMethod.DELETE }, allowCredentials = "true", allowedHeaders = CorsConfiguration.ALL, exposedHeaders = {}, maxAge = 1800)
public class CustomerDriverManagementController {

	/** The service. */
	@Autowired
	private CustomerManagementServiceImpl service;

	/**
	 * Adds the customer.
	 *
	 * @param customerDto the customer dto
	 * @return the response entity
	 */
	@PostMapping(value = common.ADD_USER, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomResponse> addCustomer(@RequestBody final UserDto customerDto)

	{
		ResponseEntity<CustomResponse> responseEntity;
		Message message = null;
		CustomResponse response = null;

		int flag = service.addUser(customerDto);

		message = new Message(MessageConstants.SUCCESS);
		// response = new CustomResponse(common.SUCCESS, message, flag);
		responseEntity = new ResponseEntity<CustomResponse>(response, HttpStatus.OK);
		return responseEntity;

	}

	/**
	 * Adds the friver.
	 *
	 * @param cabDriverDto the cab driver dto
	 * @return the response entity
	 */
	@PostMapping(value = common.ADD_CAB, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomResponse> addFriver(@RequestBody final CabDriverDto cabDriverDto)

	{
		ResponseEntity<CustomResponse> responseEntity;
		Message message = null;
		CustomResponse response = null;

		int flag = service.addCabDriver(cabDriverDto);

		message = new Message(MessageConstants.SUCCESS);
		// response = new CustomResponse(common.SUCCESS, message, flag);
		responseEntity = new ResponseEntity<CustomResponse>(response, HttpStatus.OK);
		return responseEntity;

	}

}
