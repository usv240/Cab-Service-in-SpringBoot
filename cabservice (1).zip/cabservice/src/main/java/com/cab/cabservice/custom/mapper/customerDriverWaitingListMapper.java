package com.cab.cabservice.custom.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

// TODO: Auto-generated Javadoc
/**
 * The Interface customerDriverWaitingListMapper.
 */
@Mapper
public interface customerDriverWaitingListMapper {

	/** The add user waiting. */
	String addUserWaiting = "INSERT INTO public.waitlist_user(\r\n" + "	username, present_location)\r\n"
			+ "	VALUES (#{userName}, #{presentLocation});";

	/** The add cab waiting. */
	String addCabWaiting = "INSERT INTO public.waitlist_cab(\r\n" + "	username, present_location)\r\n"
			+ "	VALUES (#{userName}, #{presentLocation});";

	/**
	 * Adds the user waiting list.
	 *
	 * @param presentLocation the present location
	 * @param userName        the user name
	 */
	@Select(addUserWaiting)
	void addUserWaitingList(String presentLocation, String userName);

	/**
	 * Adds the cab waiting list.
	 *
	 * @param presentLocation the present location
	 * @param userName        the user name
	 */
	@Select(addCabWaiting)
	void addCabWaitingList(String presentLocation, String userName);

}
