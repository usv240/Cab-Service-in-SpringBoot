package com.cab.cabservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabserviceApplication.class, args);
	}

}
