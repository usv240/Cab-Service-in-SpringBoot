package com.cab.cabservice.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// TODO: Auto-generated Javadoc
/**
 * Hash code.
 *
 * @return the int
 */
@Data

/**
 * Instantiates a new ride history.
 */
@NoArgsConstructor

/**
 * Gets the fees.
 *
 * @return the fees
 */
@Getter

/**
 * Sets the fees.
 *
 * @param fees the new fees
 */
@Setter

/**
 * To string.
 *
 * @return the java.lang. string
 */
@ToString
public class Ride_History {

	/** The user name driver. */
	public String userName_Driver;

	/** The user name user. */
	public String userName_User;

	/** The start location. */
	public String startLocation;

	/** The end location. */
	public String endLocation;

	/** The date time. */
	public String dateTime;

	/** The fees. */
	public int fees;
}
