package com.cab.cabservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.cors.CorsConfiguration;

import com.cab.cabservice.common.CustomResponse;
import com.cab.cabservice.common.Message;
import com.cab.cabservice.common.MessageConstants;
import com.cab.cabservice.common.common;
import com.cab.cabservice.dto.WaitList_UserDto;
import com.cab.cabservice.service.impl.MatchCustomerDriverServiceImpl;

@RestController
@Validated

@RequestMapping("/cabservice-api")
@CrossOrigin(origins = { "http://localhost:9000" }, methods = { RequestMethod.POST, RequestMethod.GET,
		RequestMethod.PUT,
		RequestMethod.DELETE }, allowCredentials = "true", allowedHeaders = CorsConfiguration.ALL, exposedHeaders = {}, maxAge = 1800)
public class MatchCustomerDriverController {

	@Autowired
	MatchCustomerDriverServiceImpl service;

	@PostMapping(value = common.MATCH_USERS_WITH_DRIVERS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomResponse> addCustomertoWaitList()

	{
		ResponseEntity<CustomResponse> responseEntity;
		Message message = null;
		CustomResponse response = null;

		service.matchDriversUsers();

		message = new Message(MessageConstants.SUCCESS);
		// response = new CustomResponse(common.SUCCESS, message, flag);
		responseEntity = new ResponseEntity<CustomResponse>(response, HttpStatus.OK);
		return responseEntity;

	}

}
