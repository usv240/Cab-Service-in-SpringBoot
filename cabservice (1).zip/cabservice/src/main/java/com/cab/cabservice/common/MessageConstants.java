package com.cab.cabservice.common;

public class MessageConstants {

	
	public static final String NO_DATA="No Data Found";
	
	public static final String SUCCESS="Retrived Successfully";
}
