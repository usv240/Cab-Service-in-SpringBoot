package com.cab.cabservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
